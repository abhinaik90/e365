function FacultyDashboard() {
  return <h1>Faculty Dashboard</h1>;
}

export default FacultyDashboard;