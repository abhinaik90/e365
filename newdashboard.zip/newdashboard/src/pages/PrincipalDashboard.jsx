import React from "react";

export default function PrincipalDashboard() {
  return (
    <div>
      <h1>Principal Dashboard</h1>
    </div>
  );
}